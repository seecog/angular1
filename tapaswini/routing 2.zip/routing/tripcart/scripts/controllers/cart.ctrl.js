angular.module('myApp').controller('CartController',function($scope,$rootScope,$location,$routeParams){

});
