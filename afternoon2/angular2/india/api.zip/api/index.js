var express = require('express');
var mongoose = require("mongoose");
var bodyParser = require("body-parser");
var User = require("./models/user.model.js");
var app=express();
mongoose.connect("mongodb://localhost:27017/infocampus",function(){
	console.log("db connected");
});
var myRoute = express.Router();
app.use(bodyParser.urlencoded({extended : true}))
app.use(bodyParser.json())
myRoute.get("/users",function(req,res){
	
	User.find({},function(err,users){
		res.json(users)
	});	
	
});

myRoute.get("/users/:id",function(req,res){
	console.log('The request is '+req.params.id)
	User.find({_id : req.params.id},function(err,user){
		res.json(user)
	});	
});

myRoute.put("/users/:id",function(req,res){
	console.log("The body is")
	console.log(req.body)
	console.log(req.params.id)
	User.update({_id : req.params.id},{$set : req.body},function(err,user){
		console.log('The response is ')
		console.log(user)
		res.json(user);
	});
	
});

myRoute.delete("/users/:id",function(req,res){
	User.remove({_id : req.params.id},function(err,user){
		if(err)
		{
			console.log(err)
			return false;
		}
		res.json(user);
	});
});

myRoute.post('/users',function(req,res){
	var user = new User(req.body);
	User.create(user,function(err,user){
		if(err)
		{
			res.next(err)
		}
		console.log("The saved data is ")
		console.log(user)
	});
	
});
app.use("/api",myRoute);
app.listen(9091,function(){
console.log("Server started");	
});