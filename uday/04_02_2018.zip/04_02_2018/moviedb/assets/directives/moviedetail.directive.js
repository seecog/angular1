angular.module("movieApp").directive("movieDetail",function(){
    return {
    template : `
    <style>


    .healthy-snacks {
        margin: 2em auto;
        width: 90%;
        max-width: 680px;
        background: #fff;
        border-top-left-radius: 3px;
        border-top-right-radius: 3px;
        border-bottom-left-radius: 3px;
        border-bottom-right-radius: 3px;
        -webkit-backface-visibility: hidden;
        backface-visibility: hidden;
      }
      .healthy-snacks .featured-image {
        position: relative;
        overflow: hidden;
      }
      .healthy-snacks .featured-image img {
        display: block;
        width: 70% auto;
        height: auto;
        vertical-align: bottom;
        border-top-left-radius: 3px;
        border-top-right-radius: 3px;
      }
      .healthy-snacks .featured-image .arrow {
        position: absolute;
        bottom: 0;
        width: 100%;
        height: 0px;
        background-color: #fff;
      }
      .healthy-snacks .featured-image .arrow:before, .healthy-snacks .featured-image .arrow:after {
        content: '';
        position: absolute;
        bottom: 100%;
        width: 80%;
        height: 20px;
        background-color: inherit;
      }
      .healthy-snacks .featured-image .arrow:before {
        right: 80%;
        -webkit-transform-origin: 100% 100%;
        -moz-transform-origin: 100% 100%;
        -ms-transform-origin: 100% 100%;
        -o-transform-origin: 100% 100%;
        transform-origin: 100% 100%;
        -webkit-transform: skewX(45deg);
        -moz-transform: skewX(45deg);
        -ms-transform: skewX(45deg);
        -o-transform: skewX(45deg);
        transform: skewX(45deg);
      }
      .healthy-snacks .featured-image .arrow:after {
        left: 20%;
        -webkit-transform-origin: 0 100%;
        -moz-transform-origin: 0 100%;
        -ms-transform-origin: 0 100%;
        -o-transform-origin: 0 100%;
        transform-origin: 0 100%;
        -webkit-transform: skewX(-45deg);
        -moz-transform: skewX(-45deg);
        -ms-transform: skewX(-45deg);
        -o-transform: skewX(-45deg);
        transform: skewX(-45deg);
      }
      .healthy-snacks article {
        padding: 1em 1em 2em;
      }
      .healthy-snacks article::after {
        clear: both;
        content: "";
        display: table;
      }
      .healthy-snacks article header {
        border-bottom: 2px solid #9bb068;
      }
      .healthy-snacks article header h3 {
        margin: 0 0 0.25em;
        font-family: 'McLaren', cursive;
        font-size: 1.5em;
        color: #767d2e;
        text-align: center;
        text-transform: uppercase;
      }
      .healthy-snacks article .excerpt {
        font-family: 'georgia', sans-serif;
      }
      .healthy-snacks article .excerpt p {
        line-height: 20px;
        font-size:20px;
      }
      .healthy-snacks article .excerpt a {
        display: block;
        margin-top: 1em;
        color: #c00413;
        text-decoration: none;
      }
      .healthy-snacks article .excerpt a:hover {
        color: #fb2f40;
      }
      .healthy-snacks article .excerpt a span:first-child {
        padding-right: 1em;
        vertical-align: middle;
      }
      @media only screen and (min-width: 680px) {
        .healthy-snacks article header {
          width: 40%;
          float: left;
          border-bottom: none;
          border-right: 2px solid #9bb068;
        }
        .healthy-snacks article header h3 {
          margin: 1em 0;
          font-size: 2em;
        }
        .healthy-snacks article header h3 span {
          display: block;
        }
        .healthy-snacks article .excerpt {
          width: 60%;
          float: left;
          padding-left: 2em;
        }
      }
      .single {
        padding: 30px 15px;
        margin-top: 40px;
        background: #fcfcfc;
        border: 1px solid #f0f0f0; }
        .single h3.side-title {
        margin: 0;
        margin-bottom: 10px;
        padding: 0;
        font-size: 20px;
        color: #333;
        text-transform: uppercase; }
        .single h3.side-title:after {
        content: '';
        width: 60px;
        height: 1px;
        background: #ff173c;
        display: block;
        margin-top: 6px; }
        
        .single ul {
        margin-bottom: 0; }
        .single li a {
        color: #666;
        font-size: 14px;
        text-transform: uppercase;
        border-bottom: 1px solid #f0f0f0;
        line-height: 40px;
        display: block;
        text-decoration: none; }
        .single li a:hover {
        color: #ff173c; }
        .single li:last-child a {
        border-bottom: 0; }
    </style>
    <div class='healthy-snacks'>
    <div class='featured-image'>
      <!-- Image by Unknown photographer [Public domain], via Wikimedia Commons, http://commons.wikimedia.org/wiki/File%3AFruit_and_vegetables_basket.jpg -->
      <img alt='{{info.title}}' src='http://image.tmdb.org/t/p/w500{{info.poster_path}}'>
      <div class='arrow'></div>
    </div>
    <article>
      <header>
        <h3><span>{{info.title}}</span></h3>
        <hr>
        <ul class="list-group">
        <li style="font-size:14px" class="list-group-item" ng-repeat="x in info.production_companies">{{x.name}}</li> 
      </ul> 
      </header>
      <div class='excerpt'>
      <div class="single category">
		<h3 class="side-title">Genres</h3>
		<ul class="list-unstyled">
			<li style="color:red;font-size:15px" ng-repeat="x in info.genres">{{x.name}}</li>
		</ul>
   </div>
        <p style="color : #000">{{info.overview}} -- {{info.homepage}}</p>
       
        <a ng-if="info.homepage" href='{{info.homepage}}' taget="blank"><span class='fa fa-arrow-circle-right'></span><span>Visit Site</span></a>
      </div>
    </article>
  </div>
    `,
    scope : {
        info : '='
    }
    
    }
    })


    