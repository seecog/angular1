angular.module("movieApp").directive("movieThumb",function(){
return {
template : `



<style>
	.panel-default{
		text-align:center;
		cursor:pointer;
		font-family: 'Raleway',sans-serif;
	}
	.panel-default > .panel-footer {
		color: #fff;
		background-color: #47c8ed;    
		display:block;
		text-shadow: 1px 1px 1px rgba(150, 150, 150, 1);
	}
	
	</style>
	
<div class="panel panel-default">
	<div class="panel-body"> 
		<p>
		<img src="http://image.tmdb.org/t/p/w500{{info.poster_path}}" class="img-responsive">
        </p>
        <a ui-sref="home.param({id : info.id})" class="btn btn-default">View Details</a>
	</div>
	<div class="panel-footer">
    
    <h4>{{info.title}}</h4>
	</div>
</div>









`,
scope : {
info : '='
}

}
})