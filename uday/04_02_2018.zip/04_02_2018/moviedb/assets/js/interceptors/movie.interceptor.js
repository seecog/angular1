angular.module('movieApp').factory('MovieInterceptor',function(){
	var obj = {};
	obj.request=function(config){
		config.url=config.url+'&api_key=8301a21598f8b45668d5711a814f01f6';
		console.log('The config is ')
		console.log(config.url);
		return config;
	}
	obj.requestError=function(config){
		console.log('Inside error interceptor')
		console.log(config);
		return config;
	}
	obj.response=function(config){
		console.log(config);
		return config;
	}
	obj.responseError=function(config){
		console.log('Inside error interceptor response')
		console.log(config);
		return config;
	}
	
});
angular.module('movieApp').config(function($httpProvider){
$httpProvider.interceptors.push('MovieInterceptor')	
})
//https://api.themoviedb.org/3/movie/550?api_key=8301a21598f8b45668d5711a814f01f6
