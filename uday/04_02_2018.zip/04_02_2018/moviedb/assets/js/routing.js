angular.module('movieApp').config(function ($routeProvider) {
	
	$routeProvider
	.when('/',{
		templateUrl : './views/home.html',
		controller : function(MovieService,$scope){
			MovieService.getPopularMovies().then(function(res) {
				$scope.movies = res;
			})
				.catch(function (err) {
					console.log('The error is')
					console.log(err);
				})
			console.log('Inside the home ')

		}
		
		
	})
	.when('/details/:id',{
		templateUrl : './views/movieDetails.html',
		controller : function($routeParams,MovieService,$scope){
			console.log("Movie Details")
			var id = $routeParams.id;
			MovieService.getPopularMovie($routeParams.id).then(function (res) {
			//console.log('The  movie detail is ')
			//console.log(res.data)
			$scope.movie = res.data;
			})
				.catch(function (err) {
					console.log('The error is')
					console.log(err);
				})
		}
		
	});
	})
	


/*
angular.module('movieApp').config(function ($stateProvider) {
	console.log('Insde router ')
	$stateProvider.state('home', {
		url: '/',
		template: newFunction(),
		controller: function (MovieService, $scope) {
			MovieService.getPopularMovies().then(function (res) {
				$scope.movies = res;
			})
				.catch(function (err) {
					console.log('The error is')
					console.log(err);
				})
			console.log('Inside the home ')

		}
	})
	$stateProvider.state('home.param', {
		url: ':id',
		template: '<movie-detail info="movie"></movie_detail>',
		controller: function ($stateParams, MovieService,$scope) {
			console.log('Inside child' + $stateParams.id)
			MovieService.getPopularMovie($stateParams.id).then(function (res) {
			console.log('The  movie detail is ')
			$scope.movie = res.data;
			})
				.catch(function (err) {
					console.log('The error is')
					console.log(err);
				})
		}

	})
	//https://api.themoviedb.org/3/discover/movie?sort_by=popularity.desc&api_key=8301a21598f8b45668d5711a814f01f6
})*/

function newFunction() {
	return `
	
	<div class="panel panel-default" style="margin-top:20px;">
<div class="panel-heading">
<h1>Popular Movies</h1>
</div>
<div class="panel-body">

<div class="col-md-4" ng-repeat="x in movies" ng-if="$index<=2">
<movie-thumb info="x"></movie-thumb>
</div>

<div class="col-lg-12">
<ui-view></ui-view>
</div>
</div>
	</div>
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	`;
}
